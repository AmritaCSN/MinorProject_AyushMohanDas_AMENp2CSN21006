const shim = require('fabric-shim');

var Chaincode = class {

  async Init(stub) {
    console.info('Chaincode Init');
    return shim.success();
  }

  async Invoke(stub) {
    let ret = stub.getFunctionAndParameters();
    let method = this[ret.fcn];
    if (!method) {
      console.error('no method of name:' + ret.fcn + ' found');
      return shim.error('no method of name:' + ret.fcn + ' found');
    }
    try {
      let payload = await method(stub, ret.params, this);
      return shim.success(payload);
    } catch (err) {
      console.log(err);
      return shim.error(err);
    }
  }

  async create(stub, args) {
    if (args.length != 8) {
      throw new Error('Incorrect number of arguments. Expecting 8');
    }
    let id = args[0];
    let name = args[1];
    let cause = args[2];
    let state = args[3];
    let city = args[4];
    let municipality = args[5];
    let status = args[6]; // Open, Closed, Ongoing
    let mobile = args[7];

    // Validate inputs
    //validateFIRId(id);
    validateName(name);
    validateCause(cause);
    validateState(state);
    validateCity(city);
    validateMunicipality(municipality);
    validateStatus(status);
    validateMobileNumber(mobile);

    // Check if FIR with the same ID already exists
    let existingFIR = await stub.getState(id);
    if (existingFIR && existingFIR.length > 0) {
      throw new Error('FIR with the same ID already exists');
    }

    let fir = {
      name: name,
      cause: cause,
      state: state,
      city: city,
      municipality: municipality,
      status: status,
      mobile: mobile
    };

    await stub.putState(id, Buffer.from(JSON.stringify(fir)));
  }

  async query(stub, args) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting 1');
    }
    let fir = await stub.getState(args[0]);
    if (!fir) {
      throw new Error('FIR does not exist');
    }
    return fir;
  }

  async update(stub, args) {
    if (args.length != 8) {
      throw new Error('Incorrect number of arguments. Expecting 8');
    }
    let id = args[0];
    let name = args[1];
    let cause = args[2];
    let state = args[3];
    let city = args[4];
    let municipality = args[5];
    let status = args[6]; // Open, Closed, Ongoing
    let mobile = args[7];

    // Validate inputs
    //validateFIRId(id);
    validateName(name);
    validateCause(cause);
    validateState(state);
    validateCity(city);
    validateMunicipality(municipality);
    validateStatus(status);
    validateMobileNumber(mobile);

    // Check if FIR with the given ID exists
    let existingFIR = await stub.getState(id);
    if (!existingFIR || existingFIR.length === 0) {
      throw new Error('FIR does not exist');
    }

    let updatedFIR = {
      name: name,
      cause: cause,
      state: state,
      city: city,
      municipality: municipality,
      status: status,
      mobile: mobile
    };

    await stub.putState(id, Buffer.from(JSON.stringify(updatedFIR)));
  }

  async invalid(stub, args) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting 1');
    }
    let id = args[0];

    // Check if FIR with the given ID exists
    let existingFIR = await stub.getState(id);
    if (!existingFIR || existingFIR.length === 0) {
      throw new Error('FIR does not exist');
    }

    let parsedFIR = JSON.parse(existingFIR.toString());
    parsedFIR.status = 'Invalid';

    await stub.putState(id, Buffer.from(JSON.stringify(parsedFIR)));
  }
};

shim.start(new Chaincode());

//#function validateFIRId(id) {
//#  if (!/^FIR_\d{3}$/.test(id)) {
//    throw new Error('Invalid FIR ID format. Expected format: FIR_001');
//  }
//}

function validateName(name) {
  if (!/^.{1,50}$/.test(name)) {
    throw new Error('Invalid name. Maximum 50 characters allowed');
  }
}

function validateCause(cause) {
  if (!/^.{1,250}$/.test(cause)) {
    throw new Error('Invalid cause. Maximum 250 characters allowed');
  }
}

function validateState(state) {
  if (!/^.{1,25}$/.test(state)) {
    throw new Error('Invalid state. Maximum 25 characters allowed');
  }
}

function validateCity(city) {
  if (!/^.{1,25}$/.test(city)) {
    throw new Error('Invalid city. Maximum 25 characters allowed');
  }
}

function validateMunicipality(municipality) {
  if (!/^.{1,25}$/.test(municipality)) {
    throw new Error('Invalid municipality. Maximum 25 characters allowed');
  }
}

function validateStatus(status) {
  if (!/^Open|Closed|Ongoing$/.test(status)) {
    throw new Error('Invalid status. Expected values: Open, Closed, Ongoing');
  }
}

function validateMobileNumber(mobile) {
  if (!/^\d{10}$/.test(mobile)) {
    throw new Error('Invalid mobile number. Expected 10-digit number');
  }
}

shim.start(new Chaincode());

