docker start $(docker ps -a -q)
