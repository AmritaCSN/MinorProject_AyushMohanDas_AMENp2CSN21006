'use strict';

const { Gateway, Wallets } = require('fabric-network');
const fs = require('fs');
const path = require('path');

async function main() {
    try {
        // load the network configuration
        const ccpPath = path.resolve(__dirname, '.', 'connection.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        // Create a new file system based wallet for managing identities.
        const walletPath = path.join('../../profiles/vscode/wallets', 'sub1.police.com');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the admin user.
        const identity = await wallet.get('Admin');
        if (! identity) {
            console.log('Admin identity can not be found in the wallet');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'Admin', discovery: { enabled: true, asLocalhost: false } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('policechannel');

        // Get the contract from the network.
        const contract = network.getContract('fir');

        return contract; // Return the contract instance to be used in the operations

    } catch (error) {
        console.error(`Failed to submit this next transaction: ${error}`);
        process.exit(1);
    }
}

async function create(contract, firId, name, cause, location, status) {
    await contract.submitTransaction('create', firId, name, cause, location, status); 
    console.log('createFIR Transaction has been submitted');
}

async function update(contract, firId, name, cause, location, status) {
    await contract.submitTransaction('update', firId, name, cause, location, status);
    console.log('updateFIR Transaction has been submitted');
}

async function query(contract, firId) {
    const response = await contract.evaluateTransaction('query', firId);
    console.log(`queryFIR Transaction has been evaluated, result is: ${response.toString()}`);
}

async function deleteFIR(contract, firId) {
    await contract.submitTransaction('delete', firId);
    console.log('deleteFIR Transaction has been submitted');
}

module.exports = { main, create, update, query, deleteFIR };
