const express = require('express');
const bodyParser = require('body-parser');
const { main, create, update, query, deleteFIR } = require('./main.js'); // Require the necessary functions from main.js

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

let contract; // This variable will hold the contract instance

// Get the contract instance from the main function
main().then((contractInstance) => {
    contract = contractInstance;
}).catch((err) => {
    console.error(`Failed to get contract instance: ${err}`);
});

async function processTransaction(fcn, args) {
    try {
        // Depending on the function name, call the appropriate function
        if (fcn === 'create') {
            await create(contract, ...args);
        } else if (fcn === 'update') {
            await update(contract, ...args);
        } else if (fcn === 'query') {
            const result = await query(contract, ...args);
            return result;
        } else if (fcn === 'delete') {
            await deleteFIR(contract, ...args);
        }
    } catch (error) {
        console.error(`Failed to process this time transaction: ${error}`);
    }
}

app.post('/create', async (req, res) => {
    await processTransaction('create', [req.body.firID, req.body.name, req.body.cause, req.body.location, req.body.status]);
    res.send('FIR Created');
});

app.post('/update', async (req, res) => {
    await processTransaction('update', [req.body.updateFirID, req.body.updateName, req.body.updateCause, req.body.updateLocation, req.body.updateStatus]);
    res.send('FIR Updated');
});

app.post('/delete', async (req, res) => {
    await processTransaction('delete', [req.body.deleteFirID]);
    res.send('FIR Deleted');
});

app.post('/query', async (req, res) => {
    const fir = await processTransaction('query', [req.body.queryFirID]);
    res.send(`FIR: ${fir}`);
});

app.listen(3000, () => console.log('Server is running on port 3000'));

