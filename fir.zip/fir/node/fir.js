const shim = require('fabric-shim');

var Chaincode = class {

  async Init(stub) {
    console.info('Chaincode Init');
    return shim.success();
  }

  async Invoke(stub) {
    let ret = stub.getFunctionAndParameters();
    let method = this[ret.fcn];
    if (!method) {
      console.error('no method of name:' + ret.fcn + ' found');
      return shim.error('no method of name:' + ret.fcn + ' found');
    }
    try {
      let payload = await method(stub, ret.params, this);
      return shim.success(payload);
    } catch (err) {
      console.log(err);
      return shim.error(err);
    }
  }

  async create(stub, args) {
    if (args.length != 5) {
      throw new Error('Incorrect number of arguments. Expecting 5');
    }
    let id = args[0];
    let name = args[1];
    let cause = args[2];
    let location = args[3];
    let status = args[4]; // Open or Close

    let fir = {
      name: name,
      cause: cause,
      location: location,
      status: status
    };

    await stub.putState(id, Buffer.from(JSON.stringify(fir)));
  }

  async query(stub, args) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting 1');
    }
    let fir = await stub.getState(args[0]);
    if (!fir) {
      throw new Error('FIR does not exist');
    }
    return fir;
  }

  async update(stub, args) {
    if (args.length != 5) {
      throw new Error('Incorrect number of arguments. Expecting 5');
    }
    let id = args[0];
    let name = args[1];
    let cause = args[2];
    let location = args[3];
    let status = args[4]; // Open or Close

    let fir = {
      name: name,
      cause: cause,
      location: location,
      status: status
    };

    await stub.putState(id, Buffer.from(JSON.stringify(fir)));
  }

  async delete(stub, args) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting 1');
    }
    let fir = await stub.getState(args[0]);
    if (!fir) {
      throw new Error('FIR does not exist');
    }
    await stub.deleteState(args[0]);
  }
};

shim.start(new Chaincode());

